/* =========================================================
   LIGA CAIMÁN · datos del sitio (Inicio/Jornadas/Tablas/Espera)
   Reconstruido de las capturas reales del sitio.
   ========================================================= */
window.LC_SITE = {
  // tarjetas de líderes (cada una con su protagonista, foto, sparkline y enlace a tabla)
  leaders: [
    {
      role: "Pichichi", ic: "⚽", name: "JOSEF", value: 15, dec: 0, unit: "goles",
      acc: "var(--magenta)", photo: "src/media/josef.jpg",
      spark: [5, 7, 10, 10, 15],            // goles acumulados J1→J5
      extra: "5G en J1 · 5G en J5 · MVP de la J5",
      link: "Perfil Jugador.html?p=josef", linkLabel: "Ver perfil",
    },
    {
      role: "Asistencias", ic: "🎯", name: "JOSE GONZALEZ", value: 5, dec: 0, unit: "asist.",
      acc: "var(--cyan)", photo: "src/media/jose-gonzalez.jpg",
      spark: [0, 0, 0, 0, 5],               // debutó en J5
      extra: "Debutó en la J5 y lideró asistencias",
      link: "Perfil Jugador.html?p=jose-gonzalez", linkLabel: "Ver perfil",
    },
    {
      role: "Ranking Global", ic: "📊", name: "MEZA", value: 93.9, dec: 1, unit: "pts",
      acc: "var(--violet)", photo: "src/media/meza.jpg",
      spark: [0, 3, 6, 9, 9],               // puntos acumulados (forma)
      extra: "8 de 9 capitanes lo votaron Nº1",
      link: "Perfil Jugador.html?p=meza", linkLabel: "Ver perfil",
    },
    {
      role: "Líder Invicto", ic: "🛡️", name: "ANGEL", value: 12, dec: 0, unit: "pts",
      acc: "var(--lime)", photo: "src/media/angel.jpg",
      spark: [3, 6, 9, 12, 12],             // puntos acumulados
      extra: "4 victorias · 0 derrotas · sin perder",
      link: "Perfil Jugador.html?p=angel", linkLabel: "Ver perfil",
    },
  ],

  jornada6: {
    title: "IL DERBY D'ITALIA",
    sub: "Profumo di Calcio",
    teamA: "Perros Viejos", capA: "Gianni",
    teamB: "Los Emperradores", capB: "Emidio",
    tagline: "La calle contra el imperio",
    image: "src/media/jornada6.png",
    audio: "src/media/jornada6.mp3",
  },

  lastMatch: {
    jornada: 5, narr: "“Fuego vs Imperio”", date: "31 DE MAYO",
    home: "Nottingham Prisa", homeCap: "Abdon", homeScore: 11,
    away: "Los Diablos del Llano", awayCap: "Josephine", awayScore: 10,
    oro: "JOSEF",
  },

  jornadas: [
    { n: 5, date: "31 DE MAYO DE 2026",  narr: "“Fuego vs Imperio”",                 home: "Nottingham Prisa", away: "Los Diablos del Llano", hs: 11, as: 10, goals: 21, star: "Josef" },
    { n: 4, date: "1 DE MAYO DE 2026",   narr: "“El Clásico del Trabajo y el Poder”", home: "RealBañil",        away: "Patrones FC",          hs: 5,  as: 1,  goals: 6,  star: "Andres Gil" },
    { n: 3, date: "1 DE MAYO DE 2026",   narr: "“El Clásico del Buen Gusto”",         home: "Ronventus",        away: "Vodkatinto",           hs: 9,  as: 6,  goals: 15, star: "Meza" },
    { n: 2, date: "27 DE ABRIL DE 2026", narr: null,                                  home: "Masticadores",     away: "Gilzone",              hs: 9,  as: 5,  goals: 14, star: "Marco" },
    { n: 1, date: "13 DE ABRIL DE 2026", narr: null,                                  home: "Team Juandiego",   away: "Team Dantuan",         hs: 12, as: 10, goals: 22, star: "Gato" },
  ],

  // Tabla de GANADORES (clasificación principal, completa · tras J5)
  ganadores: [
    { rk: 1,  name: "Angel",        form: "WWWWN", pts: 12, invicto: true },
    { rk: 2,  name: "Josef",        form: "WWWLW", pts: 12 },
    { rk: 3,  name: "Marco",        form: "WLWWW", pts: 12 },
    { rk: 4,  name: "Daniscule",    form: "LWLWW", pts: 9 },
    { rk: 5,  name: "Juandiego",    form: "WNWWL", pts: 9 },
    { rk: 6,  name: "Meza",         form: "LWWWL", pts: 9, medal: "🏅" },
    { rk: 7,  name: "Xanderson",    form: "LWWWL", pts: 9 },
    { rk: 8,  name: "Abdon",        form: "NLWLW", pts: 6 },
    { rk: 9,  name: "Danifrg",      form: "WWLLL", pts: 6 },
    { rk: 10, name: "Gato",         form: "LLLWW", pts: 6 },
    { rk: 11, name: "Andres Gil",   form: "LLLWN", pts: 3 },
    { rk: 12, name: "Diovanny",     form: "WNNNL", pts: 3 },
    { rk: 13, name: "Emidio",       form: "WLLLL", pts: 3 },
    { rk: 14, name: "Gianni",       form: "LLLNW", pts: 3 },
    { rk: 15, name: "Jose Gonzalez",form: "NNNNW", pts: 3 },
    { rk: 16, name: "Josephine",    form: "NWLLN", pts: 3 },
    { rk: 17, name: "Lucho",        form: "NWLLN", pts: 3 },
    { rk: 18, name: "Oscar",        form: "NNWNN", pts: 3 },
    { rk: 19, name: "Redone",       form: "WNNNN", pts: 3 },
    { rk: 20, name: "Renato",       form: "LLNNW", pts: 3 },
    { rk: 21, name: "Alejo",        form: "NNNNL", pts: 0 },
    { rk: 22, name: "Danthony",     form: "LNNNN", pts: 0 },
    { rk: 23, name: "Jairo",        form: "NNNLN", pts: 0 },
    { rk: 24, name: "Winston",      form: "NLLLN", pts: 0 },
  ],

  // las otras 5 tablas: datos completos calculados del repo (tras J5)
  goleadores: [
    { name: "Josef", v: 15 }, { name: "Meza", v: 14 }, { name: "Danifrg", v: 11 },
    { name: "Gato", v: 8 }, { name: "Xanderson", v: 7 }, { name: "Andres Gil", v: 5 },
    { name: "Renato", v: 4 }, { name: "Juan (sup.)", v: 4, sub: true }, { name: "Jose Gonzalez", v: 3 },
    { name: "Redone", v: 2 }, { name: "Abdon", v: 2 }, { name: "Winston", v: 2 }, { name: "Juandiego", v: 1 },
  ],
  asistencias: [
    { name: "Jose Gonzalez", v: 5 }, { name: "Danifrg", v: 3 }, { name: "Xanderson", v: 3 },
    { name: "Meza", v: 2 }, { name: "Gato", v: 2 }, { name: "Josephine", v: 2 },
    { name: "Josef", v: 2 }, { name: "Juan (sup.)", v: 2, sub: true }, { name: "Winston", v: 1 },
    { name: "Alejo", v: 1 }, { name: "Renato", v: 1 },
  ],
  porteros: [
    { name: "Winston", played: 1, conceded: 2, avg: 2.0 },
    { name: "Josephine", played: 2, conceded: 5, avg: 2.5 },
    { name: "Lucho", played: 2, conceded: 5, avg: 2.5 },
    { name: "Andres Gil", played: 1, conceded: 5, avg: 5.0 },
    { name: "Daniscule", played: 5, conceded: 27, avg: 5.4 },
    { name: "Marco", played: 2, conceded: 13, avg: 6.5 },
    { name: "Diovanny", played: 2, conceded: 17, avg: 8.5, note: "lesión J5" },
  ],
  oroByJornada: [
    { n: 1, narr: null, winners: ["Gato"], honor: [] },
    { n: 2, narr: null, winners: ["Marco", "Daniscule"], honor: [] },
    { n: 3, narr: "El Clásico del Buen Gusto", winners: ["Meza"], honor: [] },
    { n: 4, narr: "El Clásico del Trabajo y el Poder", winners: ["Andres Gil"], honor: [{ name: "Ximena", note: "Honorífico · contribución externa" }] },
    { n: 5, narr: "Fuego vs Imperio", winners: ["Josef"], honor: [] },
  ],
  ranking: [
    { name: "Meza", score: 93.9, votes: 8, total: 9 }, { name: "Gato", score: 88.8, votes: 8, total: 9 },
    { name: "Danifrg", score: 87.5, votes: 8, total: 9 }, { name: "Josef", score: 86.7, votes: 8, total: 9 },
    { name: "Juandiego", score: 70.5, votes: 8, total: 9 }, { name: "Winston", score: 68.8, votes: 9, total: 9 },
    { name: "Danthony", score: 57.5, votes: 5, total: 9 }, { name: "Angel", score: 53.9, votes: 9, total: 9 },
    { name: "Andres Gil", score: 51.8, votes: 9, total: 9 }, { name: "Josephine", score: 50.5, votes: 6, total: 9 },
    { name: "Xanderson", score: 49.8, votes: 9, total: 9 }, { name: "Renato", score: 49.6, votes: 3, total: 9 },
    { name: "Daniscule", score: 42.2, votes: 8, total: 9 }, { name: "Marco", score: 37.8, votes: 7, total: 9 },
    { name: "Lucho", score: 26.2, votes: 9, total: 9 }, { name: "Emidio", score: 24.3, votes: 9, total: 9 },
    { name: "Abdon", score: 21.8, votes: 6, total: 9 }, { name: "Gianni", score: 11.0, votes: 7, total: 9 },
    { name: "Oscar", score: 7.8, votes: 7, total: 9 }, { name: "Jairo", score: 7.4, votes: 6, total: 9 },
    { name: "Diovanny", score: 5.3, votes: 2, total: 9 },
  ],

  waitlist: [
    { rk: 1, name: "THE BRIDGE", sponsor: "Abdon" },
    { rk: 2, name: "RUSSO",      sponsor: "Andres Gil" },
    { rk: 3, name: "DARIO",      sponsor: "Lucho" },
    { rk: 4, name: "JUANCHI",    sponsor: "Danifrg" },
    { rk: 5, name: "ARMANDO",    sponsor: "Xanderson" },
    { rk: 6, name: "JAVI GOMEZ", sponsor: "Juandiego" },
    { rk: 7, name: "JUAN DAVID", sponsor: "Gato", pending: true },
  ],
};
