/* =========================================================
   LIGA CAIMÁN · componentes
   Animaciones por setInterval (rAF/transiciones CSS van
   congeladas en algunos entornos de preview).
   ========================================================= */
const { useState, useEffect, useRef } = React;

/* ---------- detectar entrada en viewport (sin IntersectionObserver) ---------- */
function useInView(delay = 80) {
  const ref = useRef(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setOn(true), delay);
    return () => clearTimeout(t);
  }, []);
  return [ref, on];
}

/* ---------- progreso animado 0→1 (eased) ---------- */
function useProgress(duration = 850, delay = 80) {
  const [ref, on] = useInView(delay);
  const [p, setP] = useState(0);
  useEffect(() => {
    if (!on) return;
    const start = Date.now();
    const id = setInterval(() => {
      const t = Math.max(0, Math.min((Date.now() - start) / duration, 1));
      setP(1 - Math.pow(1 - t, 3));
      if (t >= 1) clearInterval(id);
    }, 16);
    return () => clearInterval(id);
  }, [on]);
  return [ref, p, on];
}

function CountUp({ value, decimals = 0, duration = 1100, prefix = "", suffix = "" }) {
  const [ref, inView] = useInView();
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = Date.now();
    const id = setInterval(() => {
      const p = Math.min((Date.now() - start) / duration, 1);
      setVal(value * (1 - Math.pow(1 - p, 3)));
      if (p >= 1) clearInterval(id);
    }, 16);
    return () => clearInterval(id);
  }, [inView, value]);
  return <span ref={ref}>{prefix}{val.toFixed(decimals)}{suffix}</span>;
}

function Reveal({ children, className = "", delay = 0 }) {
  const [ref, p] = useProgress(680, delay);
  return (
    <div ref={ref} className={className} style={{ opacity: p, transform: `translateY(${(1 - p) * 24}px)` }}>
      {children}
    </div>
  );
}

/* ---------- CROMO FIFA holográfico ---------- */
function PlayerCard({ p }) {
  const ref = useRef(null);
  const videoRef = useRef(null);
  const [videoOk, setVideoOk] = useState(false);
  useEffect(() => {
    const v = videoRef.current; if (!v) return;
    let alive = true;
    const probe = () => {
      if (!alive) return;
      if (v.videoWidth > 0) setVideoOk(true);
    };
    v.addEventListener("loadeddata", probe);
    v.addEventListener("timeupdate", probe);
    const id = setInterval(probe, 250);
    const stop = setTimeout(() => clearInterval(id), 4000);
    return () => { alive = false; v.removeEventListener("loadeddata", probe); v.removeEventListener("timeupdate", probe); clearInterval(id); clearTimeout(stop); };
  }, []);
  const onMove = (e) => {
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    el.style.transform = `rotateX(${(0.5 - py) * 15}deg) rotateY(${(px - 0.5) * 15}deg)`;
    el.style.setProperty("--mx", px * 100 + "%");
    el.style.setProperty("--my", py * 100 + "%");
    el.classList.add("hot");
  };
  const onLeave = () => {
    const el = ref.current; if (!el) return;
    el.style.transform = "rotateX(0deg) rotateY(0deg)";
    el.classList.remove("hot");
  };
  return (
    <div className="fcard-stage">
      <div className="fcard" ref={ref} onMouseMove={onMove} onMouseLeave={onLeave}>
        <div className="fcard-foil"></div>
        <div className="fcard-holo"></div>
        <div className="fcard-shine"></div>
        <div className="fcard-inner">
          <div className="fc-top">
            <div className="fc-ovr">
              <div className="num">{p.ovr}</div>
              <div className="pos">{p.pos}</div>
              <div className="div"></div>
              <div style={{ fontFamily: "var(--f-num)", fontWeight: 700, fontSize: "20px", color: "var(--lime)", letterSpacing: "-0.03em" }}>#{p.number}</div>
            </div>
            <div className="fc-badge">
              <div className="caiman">🐊</div>
              <div className="lg">LIGA CAIMÁN</div>
            </div>
          </div>
          <div className="fc-photo">
            {p.poster ? (
              <React.Fragment>
                <img className="fc-photo-img" src={p.poster} alt={p.name} />
                <video ref={videoRef} className="fc-video" src={p.video} poster={p.poster} autoPlay muted loop playsInline
                  style={{ opacity: videoOk ? 1 : 0 }}></video>
              </React.Fragment>
            ) : (
              <div className="fc-noimg"><span>{p.name.slice(0, 2)}</span></div>
            )}
            <div className="fc-photo-fade"></div>
            <div className="fc-shadow"></div>
          </div>
          <div className="fc-name">{p.name}</div>
          <div className="fc-edition">★ EDICIÓN {p.edition} ★</div>
          <div className="fc-line"></div>
          <div className="fc-stats">
            {p.cardStats.map((s) => (
              <div className="fc-stat" key={s.k}>
                <span className="v">{s.v}</span>
                <span className="k">{s.k}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- racha de forma ---------- */
function FormStreak({ form }) {
  return (
    <div className="form-row">
      {form.map((r, i) => (
        <div key={i} className={`form-pill ${r}`}>
          <span className="jn">J{i + 1}</span>
          {r}
        </div>
      ))}
    </div>
  );
}

/* ---------- gráfica de línea (ranking / puntos acumulados) ---------- */
function RankingChart({ data, field = "rank", color = "#34E6FF" }) {
  const [ref, p] = useProgress(1100);
  const W = 520, H = 210, padL = 16, padR = 16, padT = 26, padB = 34;
  const vals = data.map((d) => d[field] || 0);
  let minR = Math.min.apply(null, vals), maxR = Math.max.apply(null, vals);
  if (field === "rank") { minR = 55; maxR = 95; }
  else { const pad = Math.max(1, (maxR - minR) * 0.15); minR = Math.max(0, minR - pad); maxR = maxR + pad; if (maxR === minR) maxR = minR + 1; }
  const x = (i) => padL + i * ((W - padL - padR) / Math.max(1, data.length - 1));
  const y = (v) => padT + (1 - (v - minR) / (maxR - minR)) * (H - padT - padB);
  const pts = data.map((d, i) => [x(i), y(d[field] || 0)]);
  const line = pts.map((q, i) => (i ? "L" : "M") + q[0] + " " + q[1]).join(" ");
  const area = line + ` L ${x(data.length - 1)} ${H - padB} L ${x(0)} ${H - padB} Z`;
  const pathRef = useRef(null);
  const [len, setLen] = useState(640);
  const gid = "rk" + field;
  useEffect(() => { if (pathRef.current) setLen(pathRef.current.getTotalLength()); }, []);
  return (
    <div ref={ref}>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", display: "block" }}>
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity=".35" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((f) => (
          <line key={f} x1={padL} x2={W - padR} y1={padT + f * (H - padT - padB)} y2={padT + f * (H - padT - padB)} stroke="rgba(255,255,255,.06)" />
        ))}
        <path d={area} fill={`url(#${gid})`} style={{ opacity: p }} />
        <path ref={pathRef} d={line} fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
          style={{ strokeDasharray: len, strokeDashoffset: len * (1 - p) }} />
        {pts.map((q, i) => {
          const dp = Math.max(0, Math.min((p - i * 0.14) * 4, 1));
          return (
            <g key={i} style={{ opacity: dp }}>
              <circle cx={q[0]} cy={q[1]} r="5" fill="#06070a" stroke={color} strokeWidth="3" />
              <text x={q[0]} y={q[1] - 13} fill="#dfe9f5" fontSize="13" fontFamily="JetBrains Mono" fontWeight="700" textAnchor="middle">{data[i][field]}</text>
              <text x={q[0]} y={H - 12} fill="#7d828d" fontSize="11" fontFamily="Hanken Grotesk" fontWeight="800" textAnchor="middle">J{data[i].n}</text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

/* ---------- gráfica goles por jornada (barras que crecen) ---------- */
function GoalsChart({ data }) {
  const [ref, p] = useProgress(900);
  const max = Math.max(1, Math.max(...data.map((d) => d.g)));
  return (
    <div ref={ref} style={{ display: "flex", alignItems: "flex-end", gap: "14px", height: "186px", padding: "10px 4px 0" }}>
      {data.map((d, i) => {
        const bp = Math.max(0, Math.min((p * 1.35 - i * 0.1), 1));
        return (
          <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end", height: "100%" }}>
            <div style={{ fontFamily: "var(--f-num)", fontWeight: 700, fontSize: "20px", color: "#FF2E7E", marginBottom: "6px", opacity: bp, letterSpacing: "-0.03em" }}>{d.g}</div>
            <div style={{
              width: "100%", maxWidth: "44px", borderRadius: "9px 9px 4px 4px",
              background: "linear-gradient(180deg,#FF2E7E,#A981FF)",
              height: (d.g / max) * 100 * bp + "%",
              boxShadow: "0 8px 24px -8px rgba(255,46,126,.6)"
            }}></div>
            <div style={{ marginTop: "8px", fontFamily: "Hanken Grotesk", fontWeight: 800, fontSize: "11px", color: "#7d828d" }}>J{d.n}</div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------- radar comparativa ---------- */
function Radar({ me, them, labels }) {
  const [ref, p] = useProgress(800);
  const S = 300, c = S / 2, R = 108;
  const ang = (i) => (-90 + i * 60) * Math.PI / 180;
  const pt = (v, i) => [c + Math.cos(ang(i)) * R * (v / 100), c + Math.sin(ang(i)) * R * (v / 100)];
  const poly = (arr) => arr.map((v, i) => pt(v, i).join(",")).join(" ");
  const ring = (f) => [0, 1, 2, 3, 4, 5].map((i) => pt(f, i).join(",")).join(" ");
  return (
    <div ref={ref}>
      <svg viewBox={`0 0 ${S} ${S}`} style={{ width: "100%", maxWidth: "330px", display: "block", margin: "0 auto" }}>
        {[25, 50, 75, 100].map((f) => (
          <polygon key={f} points={ring(f)} fill="none" stroke="rgba(255,255,255,.07)" />
        ))}
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const q = pt(100, i);
          return <line key={i} x1={c} y1={c} x2={q[0]} y2={q[1]} stroke="rgba(255,255,255,.06)" />;
        })}
        <polygon points={poly(them)} fill="rgba(125,130,141,.16)" stroke="#7d828d" strokeWidth="2" style={{ opacity: Math.min(p * 1.2, 1) }} />
        <polygon points={poly(me)} fill="rgba(184,255,46,.20)" stroke="#B8FF2E" strokeWidth="2.5" style={{ opacity: Math.max(0, (p - 0.2) * 1.4) }} />
        {labels.map((l, i) => {
          const q = pt(126, i);
          return <text key={i} x={q[0]} y={q[1]} fill="#aeb4be" fontSize="12" fontFamily="Hanken Grotesk" fontWeight="800" textAnchor="middle" dominantBaseline="middle">{l}</text>;
        })}
      </svg>
    </div>
  );
}

/* ---------- logros ---------- */
function Achievements({ items }) {
  const got = items.filter((a) => a.got).length;
  return (
    <div>
      <div className="badge-grid">
        {items.map((a) => (
          <div key={a.id} className={`badge ${a.got ? "got r-" + a.rare : "locked"}`}>
            <span className="ic">{a.icon}</span>
            <div className="bn">{a.name}</div>
            <div className="bd">{a.desc}</div>
            {a.got && <div className="rarity">{a.rare === "gold" ? "Legendario" : a.rare === "epic" ? "Épico" : a.rare === "rare" ? "Raro" : "Común"}</div>}
          </div>
        ))}
      </div>
      <div className="badge-progress">
        <span style={{ fontFamily: "var(--f-num)", fontWeight: 700, fontSize: "26px", color: "var(--ink)", letterSpacing: "-0.03em" }}>{got}/{items.length}</span>
        <div className="bar"><span style={{ width: (got / items.length) * 100 + "%" }}></span></div>
        <span>logros desbloqueados</span>
      </div>
    </div>
  );
}

/* ---------- química ---------- */
function Chemistry({ items }) {
  const rate = (it) => (it.w + it.l ? it.w / (it.w + it.l) : 0);
  const bestI = items.reduce((b, it, i, a) => (rate(it) > rate(a[b]) || (rate(it) === rate(a[b]) && it.w + it.l > a[b].w + a[b].l)) ? i : b, 0);
  const worstI = items.reduce((b, it, i, a) => rate(it) < rate(a[b]) ? i : b, 0);
  return (
    <div className="chem-list">
      {items.map((it, i) => (
        <div key={it.name} className={`chem ${i === bestI ? "best" : ""} ${i === worstI ? "worst" : ""}`}>
          <div className="who">
            <span className="nm">{it.name}</span>
            {i === bestI ? <span className="chem-flag">★ Mejor dupla</span>
              : i === worstI ? <span className="chem-flag">⚠ Tu kryptonita</span>
                : <span className="nt">{it.note || `${it.w + it.l} juntos`}</span>}
          </div>
          <div className="chem-bar"><span style={{ width: rate(it) * 100 + "%" }}></span></div>
          <div className="rec">
            <span className="w">{it.w}V</span> · <span className="l">{it.l}D</span>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------- historial ---------- */
function History({ rows }) {
  return (
    <div className="hist">
      {rows.slice().reverse().map((d) => {
        const [a, b] = d.score.split("-");
        return (
          <div key={d.n} className="hrow">
            <div className={`res ${d.res}`}>{d.res === "W" ? "V" : "D"}</div>
            <div className="mid">
              <div className="jn">JORNADA {d.n}{d.oro ? "  ·  🐊 CAIMÁN DE ORO" : ""}</div>
              <div className="mt"><b>{d.team}</b> <span>vs {d.opp}</span></div>
            </div>
            <div className="right">
              <div className="ga">
                <div className="item"><div className="n g">{d.g}</div><div className="l">Goles</div></div>
                <div className="item"><div className="n a">{d.a}</div><div className="l">Asist.</div></div>
              </div>
              <div className="score">
                <span className={d.res === "W" ? "w" : "x"}>{a}</span><span className="x">-{b}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

Object.assign(window, {
  useInView, useProgress, CountUp, Reveal, PlayerCard, FormStreak,
  RankingChart, GoalsChart, Radar, Achievements, Chemistry, History,
});
