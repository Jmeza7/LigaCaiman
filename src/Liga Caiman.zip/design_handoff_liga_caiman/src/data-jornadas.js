window.LC_JORNADAS = [
 {
  "n": 1,
  "date": "2026-04-13",
  "narr": null,
  "home": {
   "name": "Team Juandiego",
   "cap": "Juandiego",
   "colors": {
    "primary": "#ffffff",
    "secondary": "#000000"
   },
   "score": 12,
   "players": [
    "Juandiego",
    "Danifrg",
    "Josef",
    "Diovanny",
    "Emidio",
    "Angel",
    "Marco",
    "Redone"
   ]
  },
  "away": {
   "name": "Team Dantuan",
   "cap": "Danthony",
   "colors": {
    "primary": "#000000",
    "secondary": "#ffffff"
   },
   "score": 10,
   "players": [
    "Danthony",
    "Meza",
    "Gato",
    "Renato",
    "Andres Gil",
    "Xanderson",
    "Daniscule",
    "Gianni"
   ]
  },
  "total": 22,
  "avg": 15.6,
  "pct": 41,
  "mvps": [
   {
    "id": "gato",
    "name": "Gato",
    "type": "normal",
    "notes": null
   }
  ],
  "desc": null,
  "ytTitle": "Jornada 1",
  "ytId": null,
  "goals": [
   {
    "min": null,
    "scorer": "Danifrg",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Danifrg",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Danifrg",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Danifrg",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Danifrg",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Josef",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Josef",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Josef",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Josef",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Josef",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Redone",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Redone",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Meza",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Meza",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Meza",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Meza",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Gato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Gato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Gato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Gato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Andres Gil",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Renato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   }
  ],
  "top5": [
   {
    "name": "Angel",
    "pts": 3,
    "delta": 0
   },
   {
    "name": "Danifrg",
    "pts": 3,
    "delta": 0
   },
   {
    "name": "Diovanny",
    "pts": 3,
    "delta": 0
   },
   {
    "name": "Emidio",
    "pts": 3,
    "delta": 0
   },
   {
    "name": "Josef",
    "pts": 3,
    "delta": 0
   }
  ]
 },
 {
  "n": 2,
  "date": "2026-04-27",
  "narr": null,
  "home": {
   "name": "Masticadores",
   "cap": "Xanderson",
   "colors": {
    "primary": "#ffffff",
    "secondary": "#000000"
   },
   "score": 9,
   "players": [
    "Xanderson",
    "Josef",
    "Meza",
    "Danifrg",
    "Daniscule",
    "Josephine",
    "Angel",
    "Lucho"
   ]
  },
  "away": {
   "name": "Gilzone",
   "cap": "Andres Gil",
   "colors": {
    "primary": "#000000",
    "secondary": "#ffffff"
   },
   "score": 5,
   "players": [
    "Andres Gil",
    "Winston",
    "Gato",
    "Renato",
    "Marco",
    "Gianni",
    "Emidio",
    "Abdon"
   ]
  },
  "total": 14,
  "avg": 15.6,
  "pct": -10,
  "mvps": [
   {
    "id": "marco",
    "name": "Marco",
    "type": "normal",
    "notes": null
   },
   {
    "id": "daniscule",
    "name": "Daniscule",
    "type": "normal",
    "notes": null
   }
  ],
  "desc": null,
  "ytTitle": "Jornada 2",
  "ytId": null,
  "goals": [
   {
    "min": null,
    "scorer": "Xanderson",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Xanderson",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Xanderson",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Danifrg",
    "assist": "Meza",
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Danifrg",
    "assist": "Meza",
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Josef",
    "assist": "Danifrg",
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Josef",
    "assist": "Danifrg",
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Meza",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Meza",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Renato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Renato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Gato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Gato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Andres Gil",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   }
  ],
  "top5": [
   {
    "name": "Angel",
    "pts": 6,
    "delta": 0
   },
   {
    "name": "Danifrg",
    "pts": 6,
    "delta": 0
   },
   {
    "name": "Josef",
    "pts": 6,
    "delta": 2
   },
   {
    "name": "Daniscule",
    "pts": 3,
    "delta": 6
   },
   {
    "name": "Diovanny",
    "pts": 3,
    "delta": -2
   }
  ]
 },
 {
  "n": 3,
  "date": "2026-05-01",
  "narr": "El Clásico del Buen Gusto",
  "home": {
   "name": "Ronventus",
   "cap": "Marco",
   "colors": {
    "primary": "#ffffff",
    "secondary": "#000000"
   },
   "score": 9,
   "players": [
    "Marco",
    "Josef",
    "Juandiego",
    "Meza",
    "Xanderson",
    "Abdon",
    "Angel",
    "Oscar"
   ]
  },
  "away": {
   "name": "Vodkatinto",
   "cap": "Daniscule",
   "colors": {
    "primary": "#8B0000",
    "secondary": "#ffffff"
   },
   "score": 6,
   "players": [
    "Daniscule",
    "Gato",
    "Danifrg",
    "Winston",
    "Andres Gil",
    "Lucho",
    "Emidio",
    "Gianni"
   ]
  },
  "total": 15,
  "avg": 15.6,
  "pct": -4,
  "mvps": [
   {
    "id": "meza",
    "name": "Meza",
    "type": "normal",
    "notes": null
   }
  ],
  "desc": "Volley legendario de Meza que no se grabó (cámara apagada).",
  "ytTitle": "J3 — El Clásico del Buen Gusto",
  "ytId": null,
  "goals": [
   {
    "min": null,
    "scorer": "Josef",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Josef",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Josef",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Meza",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Meza",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Meza",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Xanderson",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Abdon",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Juandiego",
    "assist": null,
    "keeper": null,
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Winston",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Winston",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Danifrg",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Danifrg",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Gato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Gato",
    "assist": null,
    "keeper": null,
    "team": "away",
    "after": null,
    "sub": false
   }
  ],
  "top5": [
   {
    "name": "Angel",
    "pts": 9,
    "delta": 0
   },
   {
    "name": "Josef",
    "pts": 9,
    "delta": 1
   },
   {
    "name": "Danifrg",
    "pts": 6,
    "delta": -1
   },
   {
    "name": "Juandiego",
    "pts": 6,
    "delta": 4
   },
   {
    "name": "Marco",
    "pts": 6,
    "delta": 5
   }
  ]
 },
 {
  "n": 4,
  "date": "2026-05-01",
  "narr": "El Clásico del Trabajo y el Poder",
  "home": {
   "name": "RealBañil",
   "cap": "Gato",
   "colors": {
    "primary": "#2d6a2d",
    "secondary": "#c0a000"
   },
   "score": 5,
   "players": [
    "Gato",
    "Meza",
    "Marco",
    "Juandiego",
    "Xanderson",
    "Angel",
    "Andres Gil",
    "Daniscule"
   ]
  },
  "away": {
   "name": "Patrones FC",
   "cap": "Josef",
   "colors": {
    "primary": "#f8f8f8",
    "secondary": "#d4af37"
   },
   "score": 1,
   "players": [
    "Josef",
    "Danifrg",
    "Winston",
    "Josephine",
    "Lucho",
    "Abdon",
    "Emidio",
    "Jairo"
   ]
  },
  "total": 6,
  "avg": 15.6,
  "pct": -62,
  "mvps": [
   {
    "id": "andres-gil",
    "name": "Andres Gil",
    "type": "normal",
    "notes": null
   },
   {
    "id": "ximena",
    "name": "Ximena",
    "type": "honorary",
    "notes": "Caimán de Oro Honorífico por contribución externa a la liga"
   }
  ],
  "desc": "Falta dura de Josef a Gato. Josef pierde su invicto. Hat-trick de Andres Gil.",
  "ytTitle": "J4 — El Clásico Social",
  "ytId": null,
  "goals": [
   {
    "min": null,
    "scorer": "Andres Gil",
    "assist": null,
    "keeper": "Lucho",
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Andres Gil",
    "assist": null,
    "keeper": "Lucho",
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Andres Gil",
    "assist": null,
    "keeper": "Lucho",
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Xanderson",
    "assist": "Winston",
    "keeper": "Josephine",
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Xanderson",
    "assist": "Gato",
    "keeper": "Josephine",
    "team": "home",
    "after": null,
    "sub": false
   },
   {
    "min": null,
    "scorer": "Danifrg",
    "assist": null,
    "keeper": "Daniscule",
    "team": "away",
    "after": null,
    "sub": false
   }
  ],
  "top5": [
   {
    "name": "Angel",
    "pts": 12,
    "delta": 0
   },
   {
    "name": "Josef",
    "pts": 9,
    "delta": 0
   },
   {
    "name": "Juandiego",
    "pts": 9,
    "delta": 1
   },
   {
    "name": "Marco",
    "pts": 9,
    "delta": 1
   },
   {
    "name": "Meza",
    "pts": 9,
    "delta": 1
   }
  ]
 },
 {
  "n": 5,
  "date": "2026-05-31",
  "narr": "Fuego vs Imperio",
  "home": {
   "name": "Nottingham Prisa",
   "cap": "Abdon",
   "colors": {
    "primary": "#1a1a4e",
    "secondary": "#d4af37"
   },
   "score": 11,
   "players": [
    "Abdon",
    "Josef",
    "Gato",
    "Renato",
    "Jose Gonzalez",
    "Daniscule",
    "Marco",
    "Gianni"
   ]
  },
  "away": {
   "name": "Los Diablos del Llano",
   "cap": "Josephine",
   "colors": {
    "primary": "#8b0000",
    "secondary": "#111111"
   },
   "score": 10,
   "players": [
    "Josephine",
    "Meza",
    "Danifrg",
    "Juandiego",
    "Xanderson",
    "Alejo",
    "Emidio",
    "Diovanny"
   ]
  },
  "total": 21,
  "avg": 15.6,
  "pct": 35,
  "mvps": [
   {
    "id": "josef",
    "name": "Josef",
    "type": "normal",
    "notes": null
   }
  ],
  "desc": "21 goles totales, 1 gol de diferencia. El partido más loco de la temporada.",
  "ytTitle": "J5 — Fuego vs Imperio",
  "ytId": null,
  "goals": [
   {
    "min": "3:08",
    "scorer": "Josef",
    "assist": "Jose Gonzalez",
    "keeper": "Diovanny",
    "team": "home",
    "after": {
     "home": 1,
     "away": 0
    },
    "sub": false
   },
   {
    "min": "3:53",
    "scorer": "Meza",
    "assist": "Xanderson",
    "keeper": "Daniscule",
    "team": "away",
    "after": {
     "home": 1,
     "away": 1
    },
    "sub": false
   },
   {
    "min": "6:00",
    "scorer": "Meza",
    "assist": "Josephine",
    "keeper": "Daniscule",
    "team": "away",
    "after": {
     "home": 1,
     "away": 2
    },
    "sub": false
   },
   {
    "min": "7:31",
    "scorer": "Juan (sup.)",
    "assist": "Jose Gonzalez",
    "keeper": "Diovanny",
    "team": "home",
    "after": {
     "home": 2,
     "away": 2
    },
    "sub": true
   },
   {
    "min": "9:16",
    "scorer": "Josef",
    "assist": "Gato",
    "keeper": "Diovanny",
    "team": "home",
    "after": {
     "home": 3,
     "away": 2
    },
    "sub": false
   },
   {
    "min": "15:51",
    "scorer": "Xanderson",
    "assist": null,
    "keeper": "Daniscule",
    "team": "away",
    "after": {
     "home": 3,
     "away": 3
    },
    "sub": false
   },
   {
    "min": "18:10",
    "scorer": "Josef",
    "assist": null,
    "keeper": "Diovanny",
    "team": "home",
    "after": {
     "home": 4,
     "away": 3
    },
    "sub": false
   },
   {
    "min": "39:56",
    "scorer": "Renato",
    "assist": "Jose Gonzalez",
    "keeper": "Diovanny",
    "team": "home",
    "after": {
     "home": 5,
     "away": 3
    },
    "sub": false
   },
   {
    "min": "41:45",
    "scorer": "Abdon",
    "assist": "Jose Gonzalez",
    "keeper": "Diovanny",
    "team": "home",
    "after": {
     "home": 6,
     "away": 3
    },
    "sub": false
   },
   {
    "min": "52:50",
    "scorer": "Josef",
    "assist": "Jose Gonzalez",
    "keeper": "Diovanny",
    "team": "home",
    "after": {
     "home": 7,
     "away": 3
    },
    "sub": false
   },
   {
    "min": "55:17",
    "scorer": "Meza",
    "assist": "Alejo",
    "keeper": "Daniscule",
    "team": "away",
    "after": {
     "home": 7,
     "away": 4
    },
    "sub": false
   },
   {
    "min": "56:33",
    "scorer": "Jose Gonzalez",
    "assist": "Josef",
    "keeper": "Diovanny",
    "team": "home",
    "after": {
     "home": 8,
     "away": 4
    },
    "sub": false
   },
   {
    "min": "63:27",
    "scorer": "Jose Gonzalez",
    "assist": "Renato",
    "keeper": "Josephine",
    "team": "home",
    "after": {
     "home": 9,
     "away": 4
    },
    "sub": false
   },
   {
    "min": "67:39",
    "scorer": "Josef",
    "assist": null,
    "keeper": "Josephine",
    "team": "home",
    "after": {
     "home": 10,
     "away": 4
    },
    "sub": false
   },
   {
    "min": "68:09",
    "scorer": "Meza",
    "assist": "Juan (sup.)",
    "keeper": "Daniscule",
    "team": "away",
    "after": {
     "home": 10,
     "away": 5
    },
    "sub": false
   },
   {
    "min": "70:31",
    "scorer": "Danifrg",
    "assist": "Xanderson",
    "keeper": "Daniscule",
    "team": "away",
    "after": {
     "home": 10,
     "away": 6
    },
    "sub": false
   },
   {
    "min": "72:22",
    "scorer": "Jose Gonzalez",
    "assist": "Josef",
    "keeper": "Josephine",
    "team": "home",
    "after": {
     "home": 11,
     "away": 6
    },
    "sub": false
   },
   {
    "min": "72:57",
    "scorer": "Juan (sup.)",
    "assist": "Danifrg",
    "keeper": "Daniscule",
    "team": "away",
    "after": {
     "home": 11,
     "away": 7
    },
    "sub": true
   },
   {
    "min": "74:48",
    "scorer": "Juan (sup.)",
    "assist": "Josephine",
    "keeper": "Daniscule",
    "team": "away",
    "after": {
     "home": 11,
     "away": 8
    },
    "sub": true
   },
   {
    "min": "76:50",
    "scorer": "Juan (sup.)",
    "assist": "Xanderson",
    "keeper": "Daniscule",
    "team": "away",
    "after": {
     "home": 11,
     "away": 9
    },
    "sub": true
   },
   {
    "min": "81:38",
    "scorer": "Meza",
    "assist": "Juan (sup.)",
    "keeper": "Daniscule",
    "team": "away",
    "after": {
     "home": 11,
     "away": 10
    },
    "sub": false
   }
  ],
  "top5": [
   {
    "name": "Angel",
    "pts": 12,
    "delta": 0
   },
   {
    "name": "Josef",
    "pts": 12,
    "delta": 0
   },
   {
    "name": "Marco",
    "pts": 12,
    "delta": 1
   },
   {
    "name": "Daniscule",
    "pts": 9,
    "delta": 4
   },
   {
    "name": "Juandiego",
    "pts": 9,
    "delta": -2
   }
  ]
 }
];
