/* =========================================================
   LIGA CAIMÁN · perfil dinámico (todos los jugadores)
   Lee ?p=<id> de la URL. Datos: window.LC_PLAYERS
   ========================================================= */
const PLAYERS = window.LC_PLAYERS;
const ORDER = window.LC_PLAYER_ORDER;
const LEAGUE_MAX_GOALS = Math.max.apply(null, Object.values(PLAYERS).map(function (p) { return p.goals; }));

function getPID() {
  const m = location.search.match(/[?&]p=([^&]+)/);
  const id = m ? decodeURIComponent(m[1]) : "josef";
  return PLAYERS[id] ? id : "josef";
}
const PID = getPID();
const RAW = PLAYERS[PID];

/* ---- adaptador: forma que esperan los componentes ---- */
const P = (function (r) {
  return {
    id: r.id, name: r.name.toUpperCase(), status: r.status, pos: r.pos, ovr: r.ovr,
    edition: r.edition, number: r.rankPos || "—",
    video: r.video, poster: r.photo,
    goals: r.goals, assists: r.assists, played: r.played, wins: r.wins, losses: r.losses,
    points: r.points, ranking: r.ranking, rankPos: r.rankPos, rankVotes: r.rankVotes,
    oro: r.oro, unbeaten: r.unbeaten, keeper: r.keeper, joined: r.joined,
    form: r.form, cardStats: r.cardStats, history: r.history, chem: r.chem,
  };
})(RAW);

/* ---- logros generados de datos reales ---- */
function buildAchievements(r) {
  const maxJ = r.history.reduce(function (m, h) { return Math.max(m, h.g); }, 0);
  const isTop = r.goals > 0 && r.goals === LEAGUE_MAX_GOALS;
  const A = [
    { id: "debut", name: "Debut", desc: "Jugó su primera caimana", icon: "🌱", got: r.played > 0, rare: "common" },
    { id: "pichichi", name: "Pichichi", desc: "Máximo goleador de la liga", icon: "⚽", got: isTop, rare: "gold" },
    { id: "oro", name: "Caimán de Oro", desc: r.oro ? r.oro + " vez(es) MVP" : "Ser MVP de una jornada", icon: "🐊", got: r.oro > 0, rare: "gold" },
    { id: "rank1", name: "Nº1 del ranking", desc: "Liderar el ranking global", icon: "👑", got: r.rankPos === 1, rare: "gold" },
    { id: "invicto", name: "Invicto", desc: "Temporada sin perder", icon: "🛡️", got: r.unbeaten, rare: "gold" },
    { id: "manita", name: "Manita", desc: "5 goles en una jornada", icon: "🖐️", got: maxJ >= 5, rare: "epic" },
    { id: "hat", name: "Hat-trick", desc: "3+ goles en una jornada", icon: "🎩", got: maxJ >= 3, rare: "epic" },
    { id: "doble", name: "Doble dígito", desc: "10+ goles en la temporada", icon: "🔟", got: r.goals >= 10, rare: "rare" },
    { id: "asist", name: "Asistente", desc: "5+ asistencias", icon: "🎯", got: r.assists >= 5, rare: "rare" },
    { id: "muro", name: "El Muro", desc: "Portero: < 3 goles/partido", icon: "🧤", got: !!(r.keeper && r.keeper.avg < 3), rare: "epic" },
  ];
  // muestra solo los relevantes: todos los conseguidos + algunos retos cercanos
  const got = A.filter(function (a) { return a.got; });
  const locked = A.filter(function (a) { return !a.got && a.id !== "muro"; });
  const showLocked = r.keeper ? A.filter(function (a) { return !a.got; }) : locked;
  return got.concat(showLocked).slice(0, 10);
}
const ACHIEVEMENTS = buildAchievements(RAW);

/* ---- rivales: top del ranking (excluyendo a uno mismo) ---- */
const RIVALS = ORDER.filter(function (id) { return id !== PID && PLAYERS[id].ranking != null; })
  .slice(0, 3).map(function (id) {
    const o = PLAYERS[id];
    return { name: o.name.toUpperCase(), tag: "#" + o.rankPos, cardStats: o.cardStats };
  });

function Nav() {
  return (
    <nav className="nav">
      <div className="nav-in">
        <a className="logo" href="index.html" style={{ textDecoration: "none" }}>
          <span className="mark">🐊</span>
          <span className="name"><span className="a">LIGA</span> <span className="b">CAIMÁN</span></span>
        </a>
        <div className="nav-links">
          <a href="index.html">Inicio</a>
          <a href="jornadas.html">Jornadas</a>
          <a href="tablas.html" className="active">Tablas</a>
          <a href="reglas.html">Reglas</a>
          <a href="espera.html">Espera</a>
        </div>
      </div>
    </nav>
  );
}

/* ---- selector de jugadores ---- */
function PlayerSwitcher() {
  const i = ORDER.indexOf(PID);
  const prev = i > 0 ? ORDER[i - 1] : null;
  const next = i < ORDER.length - 1 ? ORDER[i + 1] : null;
  return (
    <div className="pswitch">
      <div className="pswitch-rail">
        {ORDER.map(function (id) {
          const o = PLAYERS[id];
          return (
            <a key={id} href={"Perfil Jugador.html?p=" + id} className={"pchip" + (id === PID ? " active" : "")}>
              <span className="pr">{o.rankPos || "—"}</span>{o.name}
            </a>
          );
        })}
      </div>
    </div>
  );
}

function Hero() {
  const tags = [];
  tags.push({ cls: "live", el: <span><span className="dot"></span> {RAW.status === "active" ? "ACTIVO" : RAW.status}</span> });
  if (P.goals === LEAGUE_MAX_GOALS && P.goals > 0) tags.push({ cls: "gold", el: "★ PICHICHI" });
  if (P.oro > 0) tags.push({ cls: "gold", el: "🐊 CAIMÁN DE ORO" });
  if (P.rankPos === 1) tags.push({ cls: "gold", el: "👑 Nº1 RANKING" });
  if (P.unbeaten) tags.push({ cls: "gold", el: "🛡️ INVICTO" });
  if (P.keeper) tags.push({ cls: "gold", el: "🧤 PORTERO" });

  const stats = [
    { lab: "Goles", val: P.goals, acc: "var(--magenta)", note: P.goals === LEAGUE_MAX_GOALS && P.goals > 0 ? "Pichichi de la liga" : "en " + P.played + " jornadas" },
    { lab: "Asistencias", val: P.assists, acc: "var(--cyan)", note: "pases de gol" },
    { lab: "Puntos", val: P.points, acc: "var(--lime)", note: `${P.wins}V · ${P.losses}D` },
    P.ranking != null
      ? { lab: "Ranking", val: P.ranking, dec: 1, acc: "var(--violet)", note: `#${P.rankPos} · ${P.rankVotes} votos` }
      : { lab: "Caimán Oro", val: P.oro, acc: "var(--violet)", note: P.oro ? "MVP" : "sin ranking aún" },
  ];

  const subParts = [];
  if (P.goals === LEAGUE_MAX_GOALS && P.goals > 0) subParts.push(<span key="g">Máximo goleador con <b>{P.goals} goles</b>.</span>);
  else if (P.goals > 0) subParts.push(<span key="g"><b>{P.goals} goles</b> en {P.played} jornadas.</span>);
  if (P.oro > 0) subParts.push(<span key="o"> Caimán de Oro {P.oro > 1 ? P.oro + " veces" : "vigente"}.</span>);
  if (P.unbeaten) subParts.push(<span key="u"> Sigue <b>invicto</b> esta temporada.</span>);
  if (P.keeper) subParts.push(<span key="k"> Bajo palos: {P.keeper.avg} goles encajados por partido.</span>);

  return (
    <header className="hero">
      <div className="container">
        <div className="hero-top">
          <a className="back-link" href="tablas.html">← Volver a las tablas</a>
        </div>
        <div className="hero-grid">
          <Reveal><PlayerCard p={P} /></Reveal>
          <div className="hero-right">
            <div className="hero-meta">
              {tags.map(function (t, i) { return <span key={i} className={"tag " + t.cls}>{t.el}</span>; })}
            </div>
            <h1 className="hero-name brand-grad">{P.name}</h1>
            <div className="hero-meta">
              <span className="kicker">Debut en J{P.joined || 1}</span>
              <span className="kicker" style={{ color: "var(--mut-2)" }}>·</span>
              <span className="kicker">{P.pos}{P.rankPos ? " · #" + P.rankPos + " ranking" : ""}</span>
            </div>
            <p className="hero-sub">
              {subParts.length ? subParts : <span>{P.played} jornadas jugadas en la Liga Caimán.</span>}
              {" "}Mueve el cromo para ver el holograma.
            </p>
            <div className="statgrid">
              {stats.map((s) => (
                <div className="statcard" key={s.lab} style={{ "--accent": s.acc }}>
                  <div className="lab">{s.lab}</div>
                  <div className="val"><CountUp value={s.val} decimals={s.dec || 0} /></div>
                  <div className="note">{s.note}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

function Evolution() {
  const lastP = P.history.length ? P.history[P.history.length - 1].cumP : 0;
  return (
    <section className="section">
      <div className="container">
        <div className="section-head">
          <div className="eyebrow">Crecimiento · temporada 2026</div>
          <div className="t brand-grad">Su evolución</div>
          <div className="d">Cómo creció jornada a jornada dentro de la liga.</div>
        </div>
        <div className="charts2">
          <Reveal className="panel">
            <div className="chart-title">Puntos acumulados</div>
            <div className="chart-big" style={{ color: "var(--cyan)" }}>
              <CountUp value={P.points} /><small>{P.wins} victorias · {P.losses} derrotas</small>
            </div>
            <RankingChart data={P.history} field="cumP" color="#34E6FF" />
          </Reveal>
          <Reveal className="panel" delay={120}>
            {P.goals > 0 ? (
              <div>
                <div className="chart-title">Goles por jornada</div>
                <div className="chart-big" style={{ color: "var(--magenta)" }}>
                  <CountUp value={P.goals} /><small>goles en total</small>
                </div>
                <GoalsChart data={P.history} />
              </div>
            ) : P.keeper ? (
              <div>
                <div className="chart-title">Bajo los tres palos</div>
                <div className="chart-big" style={{ color: "var(--lime)" }}>
                  <CountUp value={P.keeper.avg} decimals={1} /><small>goles encajados por partido</small>
                </div>
                <div style={{ marginTop: "10px", color: "var(--mut)", fontSize: "14px", lineHeight: 1.6 }}>
                  {P.keeper.conceded} goles encajados en {P.keeper.played} {P.keeper.played === 1 ? "partido" : "partidos"} como portero.
                </div>
              </div>
            ) : (
              <div>
                <div className="chart-title">Asistencias</div>
                <div className="chart-big" style={{ color: "var(--cyan)" }}>
                  <CountUp value={P.assists} /><small>pases de gol</small>
                </div>
                <div style={{ marginTop: "10px", color: "var(--mut)", fontSize: "14px", lineHeight: 1.6 }}>
                  Su aporte no está en el gol: {P.wins} victorias en {P.played} jornadas.
                </div>
              </div>
            )}
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Forma() {
  const played = P.form.filter((f) => f !== "N");
  const wins = P.form.filter((f) => f === "W").length;
  const pct = played.length ? Math.round((wins / played.length) * 100) : 0;
  return (
    <section className="section">
      <div className="container">
        <div className="section-head">
          <div className="eyebrow">Momento</div>
          <div className="t">Racha de forma</div>
          <div className="d">{wins} victorias en {played.length} jornadas jugadas{P.unbeaten ? " · sin perder" : ""}.</div>
        </div>
        <Reveal className="panel">
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "24px" }}>
            <FormStreak form={P.form} />
            <div style={{ textAlign: "right" }}>
              <div style={{ fontFamily: "var(--f-num)", fontWeight: 700, fontSize: "52px", color: "var(--lime)", lineHeight: 1, letterSpacing: "-0.04em" }}>
                <CountUp value={pct} suffix="%" />
              </div>
              <div className="kicker" style={{ marginTop: "4px" }}>de victorias</div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Logros() {
  return (
    <section className="section">
      <div className="container">
        <div className="section-head">
          <div className="eyebrow">Vitrina</div>
          <div className="t brand-grad">Logros</div>
          <div className="d">Insignias que se desbloquean por lo que haces en la cancha.</div>
        </div>
        <Reveal><Achievements items={ACHIEVEMENTS} /></Reveal>
      </div>
    </section>
  );
}

function Quimica() {
  if (!P.chem || !P.chem.length) return null;
  return (
    <section className="section">
      <div className="container">
        <div className="section-head">
          <div className="eyebrow">Vínculos</div>
          <div className="t">Química</div>
          <div className="d">Con quién gana y con quién se le tuerce — el draft cambia cada jornada.</div>
        </div>
        <Reveal className="panel"><Chemistry items={P.chem} /></Reveal>
      </div>
    </section>
  );
}

function Comparativa() {
  const [idx, setIdx] = useState(0);
  if (!RIVALS.length) return null;
  const rival = RIVALS[idx];
  const meVals = P.cardStats.map((s) => s.v);
  const themVals = rival.cardStats.map((s) => s.v);
  const labels = P.cardStats.map((s) => s.k);
  return (
    <section className="section">
      <div className="container">
        <div className="section-head">
          <div className="eyebrow">Cara a cara</div>
          <div className="t brand-grad">Comparativa</div>
          <div className="d">{P.name} vs los mejores del ranking, atributo por atributo.</div>
        </div>
        <div className="rival-pills">
          <span style={{ alignSelf: "center", fontFamily: "var(--f-body)", fontWeight: 800, fontSize: "12px", letterSpacing: "1.5px", color: "var(--lime)", marginRight: "4px" }}>{P.name} VS</span>
          {RIVALS.map((r, i) => (
            <button key={r.name} className={`rival-pill ${i === idx ? "active" : ""}`} onClick={() => setIdx(i)}>
              {r.name} <span style={{ opacity: .6, fontWeight: 700 }}>· {r.tag}</span>
            </button>
          ))}
        </div>
        <div className="panel">
          <div className="compare">
            <div className="cmp-rows">
              {P.cardStats.map((s, i) => (
                <div className="cmp-row" key={s.k}>
                  <div className="lbl">{s.label} · {s.k}</div>
                  <div className={`cmp-num me`}>{meVals[i]}</div>
                  <div className="cmp-track">
                    <div className="me" style={{ width: meVals[i] / (meVals[i] + themVals[i]) * 100 + "%" }}></div>
                    <div className="them" style={{ flex: 1 }}></div>
                  </div>
                  <div className={`cmp-num them`}>{themVals[i]}</div>
                </div>
              ))}
            </div>
            <div>
              <Radar me={meVals} them={themVals} labels={labels} />
              <div style={{ display: "flex", justifyContent: "center", gap: "20px", marginTop: "10px" }}>
                <span style={{ fontSize: "12px", fontWeight: 800, color: "var(--lime)" }}>● {P.name}</span>
                <span style={{ fontSize: "12px", fontWeight: 800, color: "#7d828d" }}>● {rival.name}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Historial() {
  return (
    <section className="section">
      <div className="container">
        <div className="section-head">
          <div className="eyebrow">Registro completo</div>
          <div className="t">Historial por jornada</div>
        </div>
        <Reveal><History rows={P.history} /></Reveal>
      </div>
    </section>
  );
}

function CTA() {
  const i = ORDER.indexOf(PID);
  const prev = i > 0 ? ORDER[i - 1] : null;
  const next = i < ORDER.length - 1 ? ORDER[i + 1] : null;
  return (
    <section className="section" style={{ borderTop: "none" }}>
      <div className="container">
        <div className="cta">
          <div className="t brand-grad">Explora a los demás caimanes</div>
          <div className="d">Cada jugador de la liga tiene su cromo, sus stats y su química. Salta a otro perfil o vuelve a las tablas.</div>
          <div style={{ display: "flex", gap: "10px", justifyContent: "center", flexWrap: "wrap" }}>
            {prev && <a className="btn" style={{ textDecoration: "none" }} href={"Perfil Jugador.html?p=" + prev}>← {PLAYERS[prev].name}</a>}
            {next && <a className="btn" style={{ textDecoration: "none" }} href={"Perfil Jugador.html?p=" + next}>{PLAYERS[next].name} →</a>}
            <a className="btn" style={{ textDecoration: "none", background: "var(--card-hi)", color: "var(--ink)" }} href="tablas.html">Ver tablas</a>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="motto">NO MEDIMOS EQUIPOS, MEDIMOS JUGADORES</div>
        <div className="sub">Liga Caimán · <b>Tandem Xports</b></div>
      </div>
    </footer>
  );
}

function App() {
  return (
    <div className="wrap">
      <Nav />
      <PlayerSwitcher />
      <Hero />
      <Evolution />
      <Forma />
      <Logros />
      <Quimica />
      <Comparativa />
      <Historial />
      <CTA />
      <Footer />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
