/* =========================================================
   LIGA CAIMÁN · JS compartido del sitio
   - marca el enlace de nav activo (body[data-page])
   - count-up de números [data-count]
   - reveal interpolado de [data-reveal] (no usa transición CSS,
     porque algunos previews las congelan)
   ========================================================= */
(function () {
  // ---- nav activo ----
  function markNav() {
    var page = document.body.getAttribute("data-page");
    document.querySelectorAll(".nav-links a[data-nav]").forEach(function (a) {
      if (a.getAttribute("data-nav") === page) a.classList.add("active");
    });
  }

  // ---- ease ----
  function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

  // ---- count up ----
  function countUp(el) {
    var target = parseFloat(el.getAttribute("data-count"));
    var dec = parseInt(el.getAttribute("data-dec") || "0", 10);
    var suffix = el.getAttribute("data-suffix") || "";
    var dur = 1000, start = Date.now();
    var id = setInterval(function () {
      var t = Math.min((Date.now() - start) / dur, 1);
      el.textContent = (target * easeOut(t)).toFixed(dec) + suffix;
      if (t >= 1) clearInterval(id);
    }, 16);
  }

  // ---- reveal (cascada por orden de aparición) ----
  function revealAll() {
    var els = Array.prototype.slice.call(document.querySelectorAll("[data-reveal]"));
    els.forEach(function (el, i) {
      var delay = (parseInt(el.getAttribute("data-reveal-delay") || "0", 10)) + i * 55;
      var dur = 560, start = Date.now() + delay;
      var id = setInterval(function () {
        var t = Math.max(0, Math.min((Date.now() - start) / dur, 1));
        var e = easeOut(t);
        el.style.opacity = e;
        el.style.transform = "translateY(" + (1 - e) * 22 + "px)";
        if (t >= 1) { el.style.transform = "none"; clearInterval(id); }
      }, 16);
    });
  }

  function init() {
    markNav();
    document.querySelectorAll("[data-count]").forEach(countUp);
    revealAll();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // expone para páginas con tabs
  window.LCsite = { countUp: countUp, easeOut: easeOut };
})();
