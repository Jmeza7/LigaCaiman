# Handoff: Liga Caimán — Rediseño completo del sitio

## Overview
Rediseño integral del data-hub de la **Liga Caimán** (fútbol 7 amateur, Madrid). Seis vistas: **Inicio, Jornadas, Tablas, Reglamento, Lista de Espera y Perfil de Jugador**. El objetivo doble del sitio: (1) ser un escaparate vistoso para invitar amigos a la liga, y (2) mostrar a los miembros las actualizaciones y su crecimiento personal (stats, evolución, logros, química).

La identidad visual nueva se llama **"Caimán Electric"**: fondo negro frío, acentos lima eléctrico + cian + magenta, tipografía Space Grotesk (titulares) + JetBrains Mono (números, estética de "centro de datos") + Hanken Grotesk (cuerpo). Sustituye al anterior look cálido coral/ámbar.

## About the Design Files
Los archivos de este bundle son **referencias de diseño hechas en HTML/CSS/JS** — prototipos que muestran el aspecto y comportamiento deseados, **no código para copiar tal cual**. La tarea es **recrear estos diseños dentro de tu app Next.js existente** (`liga-caiman/`), usando tus patrones, tus componentes y, sobre todo, **tus archivos de datos reales** (`data/*.json`). 

El prototipo se construyó como sitio estático independiente porque el entorno de diseño no podía escribir en tu repo. Toda la lógica de datos (cálculo de goleadores, química, OVR, etc.) está en JS plano y debe **reimplementarse como funciones/loaders en tu `lib/`** o como Server Components que leen los JSON en build time.

## Fidelity
**Alta fidelidad (hifi).** Colores, tipografía, espaciado e interacciones son finales. Recrea la UI con fidelidad de píxel usando tu stack (React/Next + el CSS o Tailwind que ya uses). Los valores exactos están en la sección *Design Tokens*.

---

## Estructura de datos (tu repo — fuente de verdad)
Todo sale de los JSON que ya tienes en `liga-caiman/data/`:
- `jornadas.json` — array de jornadas con `homeTeam`/`awayTeam` (name, captain, colors, players[]), `result`, `goals[]` (scorer, assist, minute, scoreAfter, scoredAgainst, countsForStats), `mvps[]` (playerId, type: normal|honorary, notes), `episode` (title, description, youtubeId), `narrative`.
- `players.json` — id, displayName, aliases, status, joinedJornada, tags.
- `rankings.json` — `keepers[]` (playerId, played, conceded), `globalRanking[]` (playerId, score, votes, totalCaptains), `standings[]` (playerId, record[W/L/null], points, isUnbeaten).
- `waitlist.json`, `celebrations.json`.
- Medios: `public/animations/<id>.jpg` y `<id>.mp4` (foto + vídeo de celebración por jugador); `jornadas/jornada<N>.jpeg|png` (pósters versus); `jornadas/jornada6.mp3` (audio teaser).

**Importante:** En el prototipo, `src/data-players.js`, `src/data-jornadas.js` y `src/data-site.js` son **datos PRE-CALCULADOS** a partir de esos JSON. NO los uses como fuente: replica su cálculo leyendo los JSON directamente (ver *Lógica de cálculo* abajo). Así el sitio se mantiene solo cuando añadas jornadas.

---

## Design Tokens

### Colores
```
--bg:        #06070A   (fondo principal)
--bg-2:      #0a0c11
--card:      #0e1116   (superficie de tarjeta)
--card-2:    #12151c
--card-hi:   #181c24
--line:      rgba(255,255,255,.07)   (bordes sutiles)
--line-2:    rgba(255,255,255,.13)

--ink:       #f3f5f8   (texto principal)
--ink-2:     #aeb4be   (texto secundario)
--mut:       #7d828d   (texto atenuado)
--mut-2:     #4e535d

--lime:      #B8FF2E   (primario / victorias / goleo)
--cyan:      #34E6FF   (secundario / asistencias / ranking)
--magenta:   #FF2E7E   (goles / derrotas-acento)
--violet:    #A981FF
--red:       #FF4D4D   (derrotas)
--gold:      #FFC53D   (Caimán de Oro / podio / invicto)

--grad-brand: linear-gradient(96deg, #B8FF2E 0%, #34E6FF 100%)
```

### Tipografía (Google Fonts)
```
Display:  "Space Grotesk", weight 700   → titulares, nombres, marcadores grandes
Números:  "JetBrains Mono", weight 700-800, letter-spacing -0.03 a -0.05em, NO itálica
Cuerpo:   "Hanken Grotesk", weight 400-900
```
Regla de números: SIEMPRE mono, upright (sin itálica), tracking ceñido — es la firma "data hub".

### Escala / radios / sombras
```
Contenedor máx: 1180px, padding lateral 28px
Radios: tarjetas 16-18px, pills/botones 999px, chips 10-13px
Sombra glow acento: 0 0 50px -24px <color>
Sombra elevación: 0 24px 60px -28px rgba(0,0,0,.9)
```

### Animaciones
- Entrada por scroll: fade + translateY(22px→0), ~560-680ms ease-out.
- Count-up de números desde 0, ~1000-1100ms ease-out cubic.
- Gráficas: línea se dibuja (stroke-dashoffset), barras crecen (scaleY).
- **Nota de implementación:** en el prototipo las animaciones usan `setInterval` interpolando un progreso 0→1 en vez de `requestAnimationFrame`/transiciones CSS, por una limitación del entorno de preview. **En tu Next.js usa lo normal:** CSS transitions, `IntersectionObserver` para reveal, y `requestAnimationFrame` para el count-up. Es más limpio y rinde mejor.

---

## Screens / Views

### 1. Inicio (`index.html`)
**Propósito:** portada con efecto wow + estado actual de la liga.
- **Hero con vídeo de fondo a pantalla (min-height ~64vh):** vídeo en loop, muted, `object-fit:cover`, con veil oscuro encima (radial + linear gradient a `#06070A`). Título "LIGA / CAIMÁN" apilado en dos líneas, `clamp(50px,9vw,104px)`, "LIGA" en gradiente lima→cian y "CAIMÁN" en cian. Subtítulo: `Madrid · Fútbol 7 · 5 jornadas jugadas`. Indicador "↓ Líderes de la temporada" con bob animation. *(Para el vídeo, usa un clip corto ≤20s; el prototipo cae a la celebración de un jugador como fallback.)*
- **4 tarjetas de líderes** (grid 4 col → 2 → 1). Cada tarjeta:
  - Foto del protagonista de fondo (`object-position:center 22%`) con `filter: blur(3px) brightness(.42)`, escala 1.12; en hover blur baja y escala sube.
  - Veil lineal oscuro, borde-acento de 3px a la izquierda.
  - Rol + icono arriba (ej. "⚽ Pichichi"), número grande con **count-up** (JetBrains Mono 54px, color acento) + unidad pequeña, nombre (Space Grotesk).
  - **Sparkline** SVG al pie (evolución por jornada, en color de la tarjeta).
  - **Hover:** la tarjeta crece (`max-height` de `.more` 0→90px) revelando un dato extra + botón "Ver perfil" que enlaza a `Perfil?p=<id>`.
  - Líderes: Josef (Pichichi, 15 goles, magenta) · Jose Gonzalez (Asistencias, 5, cian) · Meza (Ranking, 93.9, violeta) · Angel (Invicto, 12 pts, lima).
- **Teaser próxima jornada (J6):** kicker "⚡ Próxima jornada · J6", **póster `jornada6.png` a tamaño completo** en marco redondeado con glow, debajo los capitanes (Perros Viejos cap. Gianni VS Los Emperradores cap. Emidio). Botón de audio que reproduce `jornada6.mp3` en loop mientras se está en Inicio (autoplay con fallback a primer gesto del usuario por bloqueo de navegador; persistir on/off en localStorage `lc_j6_audio`).
- **NO** incluye historial de jornadas previas (eso vive en la página Jornadas).

### 2. Jornadas (`jornadas.html`)
**Propósito:** cada caimana al detalle. Selector de jornada (pills J1–J5) + botones Anterior/Siguiente; deep-link por hash `#j5`.
- **Cabecera cinemática:** si existe póster (`jornada<N>.jpeg`, hay de J2–J5; J6 es `.png`), se muestra a 16:9 a tamaño completo con marco + glow, y debajo una **franja de marcador** (narrativa en oro, jornada · fecha · total goles, equipos con color y capitán, marcador grande mono). Si NO hay póster (J1), se compone una cabecera "versus" generada con los `colors.primary` de cada equipo (diagonales con clip-path), marcador y narrativa.
- **Cronología de goles interactiva:** si los goles tienen `minute` (J5), línea de tiempo horizontal con un punto por gol posicionado por minuto (lima=local, magenta=visitante); hover/tap despliega un panel con goleador, asistente (cian), portero batido (magenta) y marcador en ese momento. Si no hay minutos (J1–J4), se muestran como chips en orden.
- **Stats vs la media:** número grande de goles de la jornada + dos barras (esta jornada vs media de la liga) + veredicto "+X% más loco de lo normal" (magenta si sobre la media, cian si bajo). **La media se calcula de las jornadas existentes** (con las 5 actuales = 15.6).
- **MVP en grande:** card con foto del MVP (`<id>.jpg`), badge "🐊 Caimán de Oro · J<N>", nombre, y sus stats de ESE partido (goles/asistencias calculados de `goals[]`). Soporta MVPs honoríficos (`type:honorary`, ej. Ximena en J4) en una variante sin foto.
- **Embed de YouTube:** si `episode.youtubeId` existe, `<iframe>` 16:9; si no, una portada con botón play que enlaza al canal (`@tandemxports`) usando `episode.title`/`description`. *(Actualmente todos los youtubeId son null en el repo.)*
- **Lo que cambió en las tablas:** Top 5 tras la jornada con flecha ▲/▼/— de cambio de posición respecto a la jornada anterior (calculado acumulando `standings.record`).

### 3. Tablas (`tablas.html`)
**Propósito:** 6 clasificaciones con pestañas.
- Pestañas: 🏆 Ganadores · ⚽ Goleadores · 🎯 Asistencias · 🧤 Porteros · 🐊 Caimán de Oro · 📊 Ranking Global.
- **Ganadores:** standings completos (24 jugadores) con posición, nombre, racha mini (W/L/· por jornada), puntos. Top 3 con medalla 🥇🥈🥉; invicto con tag dorado.
- **Goleadores / Asistencias / Ranking:** filas con rango, nombre, barra proporcional (color de la tabla: magenta/cian/violeta) y valor.
- **Porteros:** ordenados por goles encajados/partido ascendente; barra = solidez relativa.
- **Caimán de Oro:** por jornada (J1→J5) con narrativa, ganador(es) y menciones honoríficas.
- **Cada fila enlaza a `Perfil?p=<id>`** (mapear displayName→id).

### 4. Reglamento (`reglas.html`)
**Propósito:** documento estático. 7 secciones (Incorporación, Ciclo semanal, Pago, Día del partido, Estructura, Reglas de juego, Capitanías) + sistemas complementarios + "espíritu de la liga". Índice de navegación (TOC) con anclas. Pasos numerados, callouts (info/warn/note), chips de datos. Contenido textual incluido en el HTML — pásalo a tu CMS/MDX o déjalo estático.

### 5. Lista de Espera (`espera.html`)
**Propósito:** cola de incorporaciones desde `waitlist.json`. Filas con número de orden, nombre, sponsor (quién lo metió), tag "pendiente" si aplica. Callout explicando la prioridad por orden de llegada.

### 6. Perfil de Jugador (`Perfil Jugador.html?p=<id>`)  ← React/JSX
**Propósito:** perfil dinámico para los 24 jugadores. Lee `?p=<id>` (default josef). **En Next.js esto es la ruta dinámica que ya tienes: `app/jugador/[id]/page.tsx`.**
- **Selector de jugadores** sticky (rail horizontal con los 24, ordenados por ranking) + botones anterior/siguiente jugador en el CTA final.
- **Cromo FIFA holográfico:** se inclina con el cursor (rotateX/Y según posición del ratón), capa holográfica arcoíris + brillo que sigue al cursor (blend modes). Muestra OVR, posición, #ranking, vídeo de celebración en loop (foto `<id>.jpg` de base + `<id>.mp4` encima cuando decodifica), nombre, edición (PICHICHI/MVP/INVICTO/OFICIAL), y 6 mini-stats. **Fallback:** si no hay foto (danthony, renato, jairo), iniciales sobre fondo lima.
- **Badges dinámicos:** solo los reales (ACTIVO + Pichichi si es máximo goleador + Caimán de Oro si oro>0 + Nº1 si rankPos===1 + Invicto + Portero).
- **4 stat cards** con count-up: Goles, Asistencias, Puntos, Ranking (o Caimán Oro si no tiene ranking).
- **Evolución:** gráfica de puntos acumulados (línea) + goles por jornada (barras). Si es portero → "Bajo los tres palos" (goles encajados); si no marca → asistencias.
- **Racha de forma:** pills W/L/N por jornada + % victorias.
- **Logros:** insignias desbloqueables según umbrales reales (Debut, Pichichi, Caimán de Oro, Nº1, Invicto, Manita ≥5 en una jornada, Hat-trick ≥3, Doble dígito ≥10, Asistente ≥5, El Muro = portero <3 enc/partido). Rareza: gold/epic/rare/common con glow.
- **Química:** con quién gana/pierde (de los `players[]` compartidos por jornada y el resultado). Destaca mejor dupla y "kryptonita".
- **Comparativa (radar):** vs los 3 mejores del ranking (excluyéndose), atributo por atributo, con pills para cambiar de rival.
- **Historial** completo jornada a jornada (resultado, rival, marcador, goles/asist, marca de Caimán de Oro).

---

## Lógica de cálculo (replicar en `lib/`)
Estas funciones están implementadas en JS plano en el prototipo (`src/` scripts inline + run-time). Reimplementar leyendo los JSON:

- **Goles/Asistencias por jugador:** recorrer `jornadas[].goals[]`; contar `scorer` (si `countsForStats !== false`) y `assist` (ignorar auto-asistencia donde `assist === scorer`).
- **Victorias/derrotas/puntos:** de `rankings.standings[].record` (W=3pts) o recomputar por participación en `homeTeam/awayTeam.players[]` + `result`.
- **Química:** por jornada, para cada jugador, todos sus compañeros de equipo → acumular W/L conjuntos.
- **Media de goles/jornada:** `mean(jornadas.map(j => j.result.home + j.result.away))`.
- **Top 5 cambios:** acumular puntos tras jornada k y k-1, comparar posiciones.
- **OVR y atributos del cromo (0–99):** fórmula contextual fútbol-7 amateur (ajustable):
  ```
  GOL = clamp(40 + goals*3.5)
  ASI = clamp(45 + assists*9)
  RNK = clamp(rankingScore)        // 40 si sin ranking
  FRM = clamp(35 + winrate*60 + (invicto?10:0))
  WIN = clamp(35 + winrate*64)
  MVP = clamp(45 + oroCount*35 + rankingScore*0.15)
  OVR = clamp(mean(GOL,ASI,RNK,FRM,WIN,MVP) + (oro?4:0))
  clamp = (v) => max(1, min(99, round(v)))
  ```
  Edición del cromo: PICHICHI si oro y goals≥12, MVP si oro, INVICTO si invicto, OFICIAL en otro caso.

## Cambio de marca aplicado
En todo el sitio, "**Tanthem**" se reescribe como "**Tandem**" (footers "Tandem Xports", canal `@tandemxports`, etc.).

## Assets
Todos provienen de tu repo `liga-caiman/`:
- Fotos/vídeos de jugadores: `public/animations/<id>.jpg` + `<id>.mp4`.
- Pósters de jornada: `jornadas/jornada<N>.jpeg` (J2–J5), `jornada6.png`.
- Audio teaser: `jornadas/jornada6.mp3`.
- (Los `.mp4`/vídeos grandes NO van en este bundle por límite de tamaño; ya están en tu repo.)

## Files (referencias de diseño en este bundle)
- `index.html` — Inicio
- `jornadas.html` — Jornadas (lógica de render en el `<script>` inline)
- `tablas.html` — Tablas
- `reglas.html` — Reglamento
- `espera.html` — Lista de espera
- `Perfil Jugador.html` — Perfil (carga React + `src/app.jsx` + `src/components.jsx`)
- `src/styles.css` — tokens + identidad + cromo + secciones de perfil
- `src/site.css` — estilos de Inicio/Tablas/Reglas/Espera
- `src/jornadas.css` — estilos de la vista de jornada
- `src/app.jsx` — composición del perfil + adaptador de datos + logros/rivales
- `src/components.jsx` — Cromo, gráficas (RankingChart/GoalsChart/Radar), FormStreak, Achievements, Chemistry, History, CountUp, Reveal
- `src/caiman.js` — helpers (nav activo, count-up, reveal)
- `src/data-site.js`, `src/data-jornadas.js`, `src/data-players.js` — **datos pre-calculados de muestra (NO usar como fuente; recalcular de los JSON)**

> Para abrir el prototipo en local: servir la carpeta con cualquier static server (las páginas usan rutas relativas y los `.jsx` se transpilan con Babel en el navegador). El perfil se ve con `Perfil Jugador.html?p=meza`, etc.
